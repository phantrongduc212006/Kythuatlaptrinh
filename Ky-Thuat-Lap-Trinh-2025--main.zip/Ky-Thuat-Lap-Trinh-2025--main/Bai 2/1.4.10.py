a = "hi i am python programmer"
b = a.split()         # Tách chuỗi a thành danh sách các từ
print(b)              # In danh sách sau khi tách

c = "-".join(b)       # Nối các phần tử danh sách bằng dấu '-'
print(c)
